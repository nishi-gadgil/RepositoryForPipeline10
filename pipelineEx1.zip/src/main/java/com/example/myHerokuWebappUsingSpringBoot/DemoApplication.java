package com.example.myHerokuWebappUsingSpringBoot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.*;
import org.springframework.stereotype.*;
import java.sql.*;
import java.net.URI;

@Controller
@SpringBootApplication
public class DemoApplication {

	@RequestMapping("/")
    @ResponseBody
    String home() {
      return "Hello World! This is Nishi's First HerokuSprinhBootApp using pipeline";
    }


	public static void main(String[] args) {
		SpringApplication.run(DemoApplication.class, args);
	}
}
